const linkPath = (link) => {
    window.location.href=`${link}`
}

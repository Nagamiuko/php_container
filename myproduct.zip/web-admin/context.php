<body>
   <?php echo $title_page; ?>
</body>

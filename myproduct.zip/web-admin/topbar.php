

<body>
    <div class="bar">
        <a href="/"><button onclick="linkPath('/')"><i class="bi bi-box-arrow-up-right"></i> ไปหน้าหลักของเว็บไซต์</button></a> 
        <?php echo $title_page; ?> 
    </div>
</body>

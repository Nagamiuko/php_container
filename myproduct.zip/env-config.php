<?php
// config database 
 define("DATABASE_HOSTNAME","localhost");  // localhost ที่ใช่ปัจจุบัน
 define("DATABASE_USERNAME","my_test_data"); // ชื่อผู้ใช้ database ปัจจุบัน 
 define("DATABASE_PASSWORD","my11223344"); // รหัสผ่าน database ปัจจุบัน 
 define("DATABASE_NAME","travel"); // ชื่อ database ปัจจุบัน 
// config url api 
 define("URL_API","http://localhost:8888/api/"); // localhost:post  ที่ใช่ปัจจุบัน; // localhost:post  ที่ใช่ปัจจุบัน
 define("URL_HOST","http://localhost:8888/");

?>